import Link from 'next/link';

export function Navbar() {
  return (
    <nav className="flex justify-between items-center p-4 bg-red-600 text-white">
      <div className="text-2xl font-bold">Racely</div>
      <div className="space-x-4">
        <Link href="/">Home</Link>
        <Link href="/login">Login</Link>
        <Link href="/register">Registrati</Link>
      </div>
    </nav>
  );
}
