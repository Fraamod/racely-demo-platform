export function Footer() {
  return (
    <footer className="text-center p-4 bg-gray-200 text-sm">
      © 2025 Racely. Tutti i diritti riservati.
    </footer>
  );
}
