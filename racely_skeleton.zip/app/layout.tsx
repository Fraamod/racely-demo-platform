import '@/styles/globals.css';

export const metadata = {
  title: 'Racely',
  description: 'La piattaforma motorsport e community',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="it">
      <body className="flex flex-col min-h-screen">
        {children}
      </body>
    </html>
  );
}
