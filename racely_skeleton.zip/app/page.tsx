export default function HomePage() {
  return (
    <section className="max-w-4xl mx-auto py-16 px-6">
      <h1 className="text-4xl font-bold mb-4">Benvenuto su Racely 🚀</h1>
      <p className="text-lg mb-8">La piattaforma che connette motorsport e community.</p>
    </section>
  );
}
